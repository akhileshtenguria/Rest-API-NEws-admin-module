<?php
namespace BDC\SimpleNews\Block;
class Index extends \Magento\Framework\View\Element\Template
{

}
