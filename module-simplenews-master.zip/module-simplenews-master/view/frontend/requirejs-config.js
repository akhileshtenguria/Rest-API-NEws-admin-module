var config = {
    'map': {
        '*': {
            'mage/validation': 'BDC_SimpleNews/js/validation' 
        }
    }

     /*,
    config: {
        mixins: {
            'BDC_SimpleNews/js/validation': {
                'BDC_SimpleNews/js/validation-mixin': true
            }
        }
    }*/
};
